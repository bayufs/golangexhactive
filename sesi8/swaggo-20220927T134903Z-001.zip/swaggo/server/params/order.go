package params

type CreateOrderReq struct {
	CustomerName string
	ProductId    int
}
